import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { ThongzhiPage } from '../thongzhi/thongzhi';
import { YewuPage } from '../yewu/yewu';
@Component({
  selector: 'page-about',
  templateUrl: 'about.html'
})
export class AboutPage {

  constructor(public navCtrl: NavController) {      }


tongzhi(){
    this.navCtrl.push(ThongzhiPage);
}

yewu(){
    this.navCtrl.push(YewuPage);
} 

}




