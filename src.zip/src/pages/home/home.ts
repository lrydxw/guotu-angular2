import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { QuotePage } from '../quote/quote';
import { LeadPage } from '../lead/lead';
import { List1Page } from '../List1/List1';
import { ListGwswPage } from '../list-gwsw/list-gwsw';
import { TableKYSHPage } from '../table-kysh/table-kysh';
import { TableTKXKPage } from '../table-tkxk/table-tkxk';
import { TableGhtzPage } from '../table-ghtz/table-ghtz';
import { TableCKGHPage } from '../table-ckgh/table-ckgh';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  constructor(public navCtrl: NavController) {  }


  yewu1(){
   this.navCtrl.push(ListGwswPage);
  }

  lead(){
    this.navCtrl.push(List1Page);
  }
  gonggao(){
    this.navCtrl.push(TableKYSHPage);
  	
  }
   zhiban(){
    this.navCtrl.push(TableTKXKPage);
  	
  }
   tongyi(){
    this.navCtrl.push(TableGhtzPage);
   	
   }
   xitong(){
    this.navCtrl.push(TableCKGHPage);
   	
   }
  
}
