import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { HomeService } from "../../providers/home-service";
import { ZswfReceiveDocForm } from "./../../model/ZswfReceiveDocForm";
import { KTKhsMobile } from "./../../model/KTKhsMobile";

@Component({
	selector: 'page-table-tkxk',
	templateUrl: 'table-tkxk.html',
	providers: [HomeService]

})
export class TableTKXKPage {
	id: number; // 用来接收上一个页面传递过来的参数
	profilePicture: any = "assets/icon/date.ICO";
	mobileInfo: ZswfReceiveDocForm;
	mobileInfo1: KTKhsMobile;
	constructor(public navCtrl: NavController, public navParams: NavParams, public service: HomeService) {}

	ionViewDidLoad() {
		console.log('ionViewDidLoad TableTKXKPage');
		this.getInfo(this.id);
		this.getInfo1(this.id);

	}
	getInfo(value) {
		var url = "/API/ZSWFRECEIVEDOCFORMorK_SPBbyCaseno/'#TKQKC2016042940008'";
		var jsonstr = '{"caseno":"#TKQKC2016042940008"}';
		let body = JSON.parse(jsonstr);

		this.service.post(url, body).then(data => {
		console.log(data);
		var str = JSON.stringify(data)
		alert(str);
		var objs = JSON.parse(str); //由JSON字符串转换为JSON对象
		var obj = JSON.parse(objs.Result);
		// alert(obj.length);
		// alert(obj);
		for(let i = 0; i < obj.length; i++) {
			this.mobileInfo = obj[i];
			console.log(this.mobileInfo)
			}
		});
	}
	getInfo1(value) {

		  var url = "/API/View_k_ck_hs_mobile/";
		  var jsonstr= '{"caseno":"#TKQKC2016081740019"}';
		  let body=  JSON.parse(jsonstr);

		  this.service.post(url,body).then(data=>{console.log(data);
		  var str=JSON.stringify(data)
		  var objs = JSON.parse(str); //由JSON字符串转换为JSON对象
		  var obj= JSON.parse(objs.Result); 

		  
		// alert(obj.length);
		   // alert(obj);
		  for(let i=0;i<obj.length;i++){
		    this.mobileInfo1=obj[i];

		  console.log(this.mobileInfo1.规划处审查时间)
		  

		  }
		});/**/
	}

}