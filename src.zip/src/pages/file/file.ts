import { Component } from '@angular/core';
import { NavController, NavParams , AlertController} from 'ionic-angular';
import {HomeService} from "../../providers/home-service";
import { FileColumn } from "./../../model/FileColumn" //附件模块字段
declare var cordova: any;
/*
  Generated class for the File page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-file',
  templateUrl: 'file.html',
    providers:[HomeService]
})
export class FilePage {
 pdfjsframe:any;
 fileBase64:any;
 fileColumn: FileColumn;
 items1 = []; 
constructor(public navCtrl: NavController, 
  	public navParams: NavParams ,
  	private alertCtrl: AlertController,
  	public service:HomeService) {}

  ionViewDidLoad() {
    console.log('ionViewDidLoad FilePage');
 
    var caseno = "GWLZFW2016051242979"
    this.getFileList(caseno);
  }

  //加载数据
  getInfo(value){
    alert(111);
    cordova.plugins.FileOpenHelper.openFile("/storage/emulated/0/OCS/download/智慧国土使用手册.doc","application/msword",function(success){
      alert(success);
    }),function(error){
      alert(error);}
  }
  
openPdf(): void {

        var _self = this;

        setTimeout(() => {

            this.pdfjsframe = document.getElementById('pdfViewer');

            if (this.pdfjsframe != null) {
                this.pdfjsframe.onload = function () {
                    _self.loadPdfDocument();
                };
            }

        }, 0);
    }
    
    getFileList(value)
    {
      //alert(value);

      var url = "/API/MTRCONTENTTablebyCASENO";
      var jsonstr= '{"caseno":"'+ value +'"}';
      let body=  JSON.parse(jsonstr); 
      this.service.post(url,body).then(data => {
      console.log(data);
         var str=JSON.stringify(data);
         //alert(str);
         var objs = JSON.parse(str); //由JSON字符串转换为JSON对象
         var obj= JSON.parse(objs.Result); 
         for(let i=0;i<obj.length;i++){
           this.fileColumn = obj[i];
           this.items1.push({
             MTRNAME:this.fileColumn.MTRNAME,
             CASENO:this.fileColumn.CASENO,
             MTRTYPE:this.fileColumn.MTRTYPE
           });
             //this.power = obj[i];
             //this.SetTZHUIQIAN = obj[i];
             //(<HTMLInputElement>document.getElementById("testid")).value = this.SetTZHUIQIAN.OPINIONCONTEXT.toString();
             //this.mobileInfo.TZHUIQIAN = this.SetTZHUIQIAN.OPINIONCONTEXT.toString();
           }
      });
    }

    loadPdfDocument() {
      var API_URL="http://192.168.1.195:8081/API";
      var url = API_URL + "/MOBILECASEINFODetail/WHERE caseno='GWLZFW2016052543126'";
      //var url = API_URL + "/JCAPPInfo";
        this.service.get(url).then(data=>{console.log(data);
        var str=JSON.stringify(data)
         alert(str);
         var objs = JSON.parse(str); //由JSON字符串转换为JSON对象
         var obj= JSON.parse(objs.Result); 
        });
        var pdfData = this.base64ToUint8Array(this.fileBase64);
        var WordData = this.base64ToUint8Array(this.fileBase64);
        this.pdfjsframe.contentWindow.PDFViewerApplication.open(pdfData);
        this.pdfjsframe.contentWindow.mswordViewerApplication.open(WordData);
        this.pdfjsframe.contentWindow.open(pdfData);
    }

    base64ToUint8Array(base64) {
        var raw = atob(base64);
        var uint8Array = new Uint8Array(raw.length);
        for (var i = 0; i < raw.length; i++) {
            uint8Array[i] = raw.charCodeAt(i);
        }
        return uint8Array;
    }
    
openPdftest()
   { 
  var raw = window.atob(this.fileBase64);//decode就是pdf文件通过base64编码后再经过urldecode转过的一串字符
var rawLength = raw.length;
var array = new Uint8Array(new ArrayBuffer(rawLength));
for(var i = 0; i < rawLength; i++) {
    array[i] = raw.charCodeAt(i);
}
var pdfUrl = URL.createObjectURL(new Blob([array], {type: 'application/pdf'}));
var pdfUrl = URL.createObjectURL(new Blob([array], {type: 'application/msword'}));
   }
}
