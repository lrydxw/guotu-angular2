import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { HomeService } from "../../providers/home-service";
import { ZswfReceiveDocForm } from "./../../model/ZswfReceiveDocForm";
/*
  Generated class for the TableWjcl page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-table-wjcl',
  templateUrl: 'table-wjcl.html',
  providers: [HomeService]
})
export class TableWjclPage {
	id: number; // 用来接收上一个页面传递过来的参数
	mobileInfo: ZswfReceiveDocForm;
	
  constructor(public navCtrl: NavController, public navParams: NavParams, public service: HomeService) {}

  ionViewDidLoad() {
    console.log('ionViewDidLoad TableWjclPage');
		this.getInfo(this.id);
    
  }
  
  getInfo(value) {
		var url = "/API/FileProc/";
		var jsonstr = '{"caseno":"GWLZSW2017040640003"}';
		let body = JSON.parse(jsonstr);

		this.service.post(url, body).then(data => {
		console.log(data);
		var str = JSON.stringify(data)
		alert(str);
		var objs = JSON.parse(str); //由JSON字符串转换为JSON对象
		var obj = JSON.parse(objs.Result);
		// alert(obj.length);
		// alert(obj);
		for(let i = 0; i < obj.length; i++) {
			this.mobileInfo = obj[i];
			console.log(this.mobileInfo)
			}
		});
	}

}
