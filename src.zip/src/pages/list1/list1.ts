import {Component} from "@angular/core"
import {NavController,NavParams} from "ionic-angular"
import { MOBILECASEINFO } from "./../../model/MOBILECASEINFO"
import { HomeService } from "../../providers/home-service";
import { TablePage } from "../table/table";
import { TableKYSHPage } from "../table-kysh/table-kysh";
// @Component({
//   selector: 'page-list1',
//   templateUrl: 'list1.html'
// })
// export class List1Page {

//   constructor(public navCtrl: NavController) {

//   }

// }
//selector选择器
//templateUrl对应的模板
@Component({
    selector:'page-list1',
    templateUrl:'list1.html',
     providers:[HomeService]
})

export class List1Page{

  tablePage = TablePage;
  TableKYSHPage = TableKYSHPage;
  //  params: any = {caseno:42,flowname:"flowname",flowid:"flowid",nodeid:"nodeid",lid0:"lid0"}; //参数测试 ，最终传对象
  items2 = [];
  items1 = [];
  items: Array<{ title: String }>;
  mobileList: MOBILECASEINFO;
  constructor(public navCtrl: NavController, navParams: NavParams,
    private service: HomeService
    ) {
    	this.getInfo(1);
        this.items = [{title: 'item1'},
        {title: 'item2'},
        {title: 'item3'},
        {title: 'item4'},
        {title: 'item5'},
        {title: 'item6'},
        {title: 'item7'},
        {title: 'item8'},
        {title: 'item9'},
        {title: 'item10'},
        {title: 'item11'},
        {title: 'item12'},
        {title: 'item13'},
        {title: 'item14'},
        {title: 'item15'}];
        // for (var i = 0; i < 30; i++) {
        //   // this.items.push({title:"name"+this.items.length} );
        //   this.items3.push( {title:"item15"+i} );
        // }
    }

    // doInfinite(infiniteScroll){
    //     console.log('22');
    //     setTimeout(() => {
    //         console.log('3');
    //         infiniteScroll.complete();
    //     }, 500);
    // }
   //上拉加载
  doInfinite(infiniteScroll) {
    console.log('刷新操作');
 
    setTimeout(() => {
      for (let i = 0; i < 30; i++) {
        this.items.push( {title:"item15"+i} );
      }
 
      console.log('加载结束');
      infiniteScroll.complete();
    }, 500);
  }
 //下拉刷新
  doRefresh(refresher) {
    console.log('加载操作', refresher);
 
    setTimeout(() => {
      this.items = [];
      for (var i = 0; i < 30; i++) {
        this.items.push( {title:"item15"+i});
      }
      console.log('刷新结束');
      refresher.complete();
    }, 2000);
  }
   getInfo(value) {


      var url = "/API/MOBILECASEINFOList/where CURUSERID=6 and id0 in ('67015','67014')";

       this.service.get(url).then(data=>{console.log(data);
        var str=JSON.stringify(data)
 
         var objs = JSON.parse(str); //由JSON字符串转换为JSON对象
           var obj= JSON.parse(objs.Result); 
     
           for(let i=0;i<obj.length;i++){
              this.mobileList=obj[i];
            this.items2.push({
            	CASENAME:this.mobileList.CASENAME,
            	NODENAME:this.mobileList.NODENAME,
                FLOWNAME:this.mobileList.FLOWNAME,
            	CURDATE:this.mobileList.CURDATE,
            	
            	
            	CURUSERNAME:this.mobileList.CURUSERNAME,
            	CASENO:this.mobileList.CASENO,
            	FLOWID:this.mobileList.FLOWID,
				NODEID:this.mobileList.NODEID,
            	CURUSERID:this.mobileList.CURUSERID,
				EVENTCODE:this.mobileList.EVENTCODE,
            	EVENTNAME:this.mobileList.EVENTNAME,
            	PREINFO:this.mobileList.PREINFO,
            	LVINFO:this.mobileList.LVINFO,
            	NEXTINFO:this.mobileList.NEXTINFO,
            })
             // alert(this.mobileList.CURUSERNAME);
           }
        });
  }

}