import { Component } from '@angular/core';
import { NavController, NavParams , AlertController} from 'ionic-angular';
import {HomeService} from "../../providers/home-service";
import { MOBILECASEINFODetail } from "./../../model/MOBILECASEINFODetail";

import { FieldPower } from "./../../model/FieldPower"
import { YijiaoPage } from "../yijiao/yijiao";
import { FilePage } from "../file/file";
import { SetTZHUIQIAN } from "./../../model/SetTZHUIQIAN" //设置主管厅长意见值模块

/*
  Generated class for the Table page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-table',
  templateUrl: 'table.html',
  providers:[HomeService]
})
export class TablePage {
	YijiaoPage=YijiaoPage;
	FilePage=FilePage;
  id: number;// 用来接收上一个页面传递过来的参数
  caseno: string;// 用来接收上一个页面传递过来的参数
  flowname: string;// 用来接收上一个页面传递过来的参数
  flowid: string;// 用来接收上一个页面传递过来的参数
  nodeid: string;// 用来接收上一个页面传递过来的参数
  lid0: string;// 用来接收上一个页面传递过来的参数
  mobileInfo: MOBILECASEINFODetail;
profilePicture: any="assets/icon/date.ICO";
  items=[];
  stringjson:string;
  power:FieldPower;
  SetTZHUIQIAN:SetTZHUIQIAN;
  constructor(public navCtrl: NavController, 
  	public navParams: NavParams ,
  	 private alertCtrl: AlertController,
  	public service:HomeService) {}

  ionViewDidLoad() {
    console.log('ionViewDidLoad TablePage');
    this.caseno = this.navParams.get('CASENO');//案号：这个是通过页面跳转传过来的值
    this.flowname = this.navParams.get('FLOWNAME');//流程名 这个是通过页面跳转传过来的值
    this.flowid = this.navParams.get('FLOWID');//流程ID 这个是通过页面跳转传过来的值
    this.nodeid = this.navParams.get('NODEID');//节点ID 这个是通过页面跳转传过来的值
    this.lid0 = this.navParams.get('ID0');//表主键 这个是通过页面跳转传过来的值
    //  alert(this.caseno);
     this.getInfo();
     this.getyj();
       //字段权限设置
    this.getFieldPower();
  }
  //加载详情数据
    getInfo() {
     // var url = "/API/MOBILECASEINFODetail/WHERE caseno='GWLZFW2016052543126'";
      var url = "/API/MOBILECASEINFODetail/WHERE caseno='"+this.caseno+"'";
       this.service.get(url).then(data=>{console.log(data);
        var str=JSON.stringify(data)
         var objs = JSON.parse(str); //由JSON字符串转换为JSON对象
           var obj= JSON.parse(objs.Result); 
           for(let i=0;i<obj.length;i++){
              this.mobileInfo=obj[i];
              //    private int SFSW = Integer.MIN_VALUE;//是否上网0、内网；1、外网
             if(this.mobileInfo.SFSW==0)
             {
                this.mobileInfo.SFSWNAME="内网";
             }
             else if(this.mobileInfo.SFSW==1)
             {
               this.mobileInfo.SFSWNAME="外网";
             }
             else
             {
                this.mobileInfo.SFSWNAME=""; 
             }
             
             if(this.mobileInfo.GKXS==0)
             {
                this.mobileInfo.GKXSNAME="主动公开";
             }
             else if(this.mobileInfo.SFSW==1)
             {
               this.mobileInfo.GKXSNAME="依申请公开";
             }
            else if(this.mobileInfo.SFSW==1)
             {
               this.mobileInfo.GKXSNAME="不予公开";
             }
             else
             {
                this.mobileInfo.GKXSNAME=""; 
             }
        			 this.getTZHUIQIAN();  //主管厅长意见设置
           }
        });
  }
    
    
//意见弹框
   doConfirmYJ() {

     // var jsonstr = '[{"type":"radio","label":"同意","value":"同意"},{"type":"radio","label":"同意依法","value":"同意依法"}]';
    var buttons=JSON.parse(this.stringjson);
    let alertObj = this.alertCtrl.create();

    alertObj.setTitle('请选择审批语:');
     
    for (let i = 0; i < buttons.length; i++) {
      buttons[i].handler = doBack;
      alertObj.addInput(buttons[i]);
    }
        alertObj.present();
      function doBack(data) {
      console.log('Radio data:', data);
      this.testRadioOpen = false;
      this.testRadioResult = data.value;

      (<HTMLInputElement>document.getElementById("yijianid")).value = data.value;
       alertObj.dismiss();
    }
    }

//获取意见
   getyj()
{
 
     var url ="/API/MOBILECASEINFOSelect";
      var jsonstr= '{"userid":"ZOUQP","typename":"公文流转发文"}';
      let body=  JSON.parse(jsonstr); 
      this.service.post(url,body).then(data => {
     // console.log(data);
        var str=JSON.stringify(data)
  
         var objs = JSON.parse(str); //由JSON字符串转换为JSON对象
           var obj= JSON.parse(objs.Result); 
         
         var str1=  JSON.stringify(obj);
               console.log(str1);
      this.stringjson=str1;
    });
}
 //获取字段设置权限编辑框蓝色,可输入
  getFieldPower()
  {

    var url = "/API/MoblieTypeByFlowidAndNodeid/WHERE FlowID='10569'";
     
       this.service.get(url).then(data=>{console.log(data);
        var str=JSON.stringify(data)
        //alert(str);
         var objs = JSON.parse(str); //由JSON字符串转换为JSON对象
         var obj= JSON.parse(objs.Result); 
           for(let i=0;i<obj.length;i++){
             this.power = obj[i];
             var OPINIONNAME = this.power.OPINIONNAME.toString();
           //  alert(OPINIONNAME);
             if (OPINIONNAME == "规划处复核") {
               //{(<HTMLInputElement>document.getElementById("testid")).style="background:red;";}
               //document.getElementById("testid").style.cssText="border:1px solid blue;";
               document.getElementById("yijianid").style.cssText="border:1px solid blue;";  //改变控件的样式
               {(<HTMLInputElement>document.getElementById("yijianid")).readOnly=true;}  //设置Input控件只读
               
             }
           }
        });
  }
   //保存后获取主管厅长意见
  getTZHUIQIAN()
  {

    var url = "/API/MOBILEOPINIONTBLBystrWhere/where caseno = 'GWLZFW2016060843287'";

       this.service.get(url).then(data=>{console.log(data);
        var str=JSON.stringify(data)

         var objs = JSON.parse(str); //由JSON字符串转换为JSON对象
         var obj= JSON.parse(objs.Result); 
         for(let i=0;i<obj.length;i++){
             //this.power = obj[i];
             this.SetTZHUIQIAN = obj[i];
            // alert(this.SetTZHUIQIAN.OPINIONCONTEXT);
             (<HTMLInputElement>document.getElementById("yijianid")).value = this.SetTZHUIQIAN.OPINIONCONTEXT.toString();
             //this.mobileInfo.TZHUIQIAN = this.SetTZHUIQIAN.OPINIONCONTEXT.toString();
           }
        });
  }
  //保存功能
   save(value) {

  	var url = "/API/MOBILEOPINIONTBLNew";

    	var jsonstr = '{"caseno":"#DDXZ2016050640114","opinioncode":"PT","opinioncontext":"11","opinionman":"chenwei","opinionuserid":"11","opinioncode":"2017-4-22 10:05:51","opiniontype":"1","opinionopi":"1","activeid":"10569","type":"1","LID0":"1"}';
  	//var jsonstr = '{"caseno":"#DDXZ2016050640114","opinioncode":"PT","opinioncontext":"11","opinionman":"chenwei","opinionuserid":"11","opinioncode":"2017-4-22 10:05:51","opiniontype":"1","opinionopi":"1","activeid":"10569","type":"1","LID0":"1"}';
  	let body = JSON.parse(jsonstr);
  	this.service.post(url, body).then(data => {
  	
  	
  		var str = JSON.stringify(data)
  		console.log("str",str);
  		var objs = JSON.parse(str); //由JSON字符串转换为JSON对象
  		var obj = JSON.parse(objs.Result);
  		//alert(obj.data);
 	       if (obj.data == "1") {
    alert("保存成功！")
		//document.getElementById("btn").disabled=true;
		}else{
		//document.getElementById("btn").disabled=false;
       // oBtn.disabled = 'disabled';
		}

  	});
  }

}


