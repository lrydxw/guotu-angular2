import { Component } from '@angular/core';
import { NavController, NavParams, AlertController } from 'ionic-angular';
import { HomeService } from "../../providers/home-service";
import { MOBILECASEINFO } from "./../../model/MOBILECASEINFO"
/*
  Generated class for the Yewu page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
	selector: 'page-yewu',
	templateUrl: 'yewu.html',
	providers: [HomeService]
})
export class YewuPage {
	testRadioOpen: boolean;
	testRadioResult;
	testCheckboxOpen: boolean;
	testCheckboxResult;
	mobileInfo: MOBILECASEINFO;
	items = [];
	constructor(public navCtrl: NavController,
		public navParams: NavParams,
		private alertCtrl: AlertController, public service: HomeService) {

	}

	/* getInfo(value) {

	      var API_URL="http://192.168.1.195:8081//API";
	      var url = API_URL + "/MOBILECASEINFODetail/WHERE caseno='GWLZFW2016052543126'";
	      //var url = API_URL + "/JCAPPInfo";
	       this.service.get(url).then(data=>{console.log(data);
	        var str=JSON.stringify(data)
	        alert(str);
	         var objs = JSON.parse(str); //由JSON字符串转换为JSON对象
	           var obj= JSON.parse(objs.Result); 
	        // alert(obj.length);
	           // alert(obj);
	           for(let i=0;i<obj.length;i++){
	              this.mobileInfo=obj[i];
	              this.items.push({TITLE:this.mobileInfo.TITLE})
	              alert(this.mobileInfo.TITLE);
	           }
	        });
	  }
	 */
	ionViewDidLoad() {
		console.log('ionViewDidLoad YewuPage');
	}
	presentAlert() {
		let alert = this.alertCtrl.create({
			title: 'Low battery',
			subTitle: '10% of battery remaining',
			buttons: ['Dismiss']
		});
		alert.present();
	}

	presentConfirm() {
		let alert = this.alertCtrl.create({
			title: 'Confirm purchase',
			message: '<p>111</p><p>22</p><p>22</p><p>222</p><p>222</p>' +
				' <p>111</p>' +
				'<p>111</p>' +
				' <p>111</p>' +
				'<p>111</p>',

			buttons: [{
					text: 'Cancel',
					role: 'cancel',
					cssClass:'color:red',//没反应
					handler: () => {
						console.log('Cancel clicked');
					}
				},
				{
					text: 'Buy',
					handler: () => {
						console.log('Buy clicked');
					}
				}
			]
		});
		alert.present();
	}

	presentPrompt() {
		let alert = this.alertCtrl.create({
			title: 'Login',
			inputs: [{
					name: 'username',
					placeholder: 'Username'
				},
				{
					name: 'password',
					placeholder: 'Password',
					type: 'password'
				},
				{
					name: 'password',
					placeholder: 'Password',
					type: 'password'
				},
				{
					name: 'password',
					placeholder: 'Password',
					type: 'password'
				},
				{
					name: 'password',
					placeholder: 'Password',
					type: 'password'
				}
			],

			buttons: [{
					text: 'Cancel',
					role: 'cancel',
					handler: data => {
						console.log('Cancel clicked');
					}
				}, {
					text: 'Cancel',
					role: 'cancel',
					handler: data => {
						console.log('Cancel clicked');
					}
				},
				{
					text: 'Login',
					/* handler: data => {
					   if (User.isValid(data.username, data.password)) {
					     // logged in!
					   } else {
					     // invalid login
					     return false;
					   }
					 }*/
				}
			]
		});
		alert.present();
	}

	doConfirm(val) {

			let confirm = this.alertCtrl.create({

						title: '请选择审批用语',
						message: '<p>同意</p><p>同意依法依规办理</p>',
						buttons: [{
									text: '取消',
									handler: () => {
											alert(val);
											var v = (<HTMLInputElement>document.getElementById("testid")).value;
                    alert(v);
                   (<HTMLInputElement>document.getElementById("testid")).value=val;
               
                },
                cssClass:"color:primary"
            },
             { text: 'Cancel' },
            { text: 'ok' },
            {
                text: '确定',
                handler: () => {
                    console.log('A确定');
                }
            }
            
            
            ]
        });
        confirm.present();
    }
 
 doRadio() {
    let alert = this.alertCtrl.create();
    alert.setTitle('Lightsaber color');
 

  var API_URL="http://192.168.1.195:8081//API";
      var url = API_URL + "/MOBILECASEINFOList/where CURUSERID=6 and id0 in ('67015','67014') ";
      //var url = API_URL + "/JCAPPInfo";
       this.service.get(url).then(data=>{console.log(data);
        var str=JSON.stringify(data)
         var objs = JSON.parse(str); //由JSON字符串转换为JSON对象
           var obj= JSON.parse(objs.Result); 
        // alert(obj.length);
           // alert(obj);
           for(let i=0;i<obj.length;i++){
               this.mobileInfo=obj[i];
      alert.addInput({
      	
      type: 'radio',
      label: this.mobileInfo.CASENAME,
       value:this.mobileInfo.CASENAME
    });

           }
        });
   
    alert.addInput({
      type: 'radio',
    
      label: 'Red',
      value: 'red'
    });
 
    alert.addButton('Cancel');
    alert.addButton({
      text: 'Ok',
      handler: data => {
        console.log('Radio data:', data);
        this.testRadioOpen = false;
        this.testRadioResult = data;
        
         var v =  (<HTMLInputElement>document.getElementById("testid1")).value;

                   (<HTMLInputElement>document.getElementById("testid1")).value=data;
      },
    });
  alert.present();
 
    /*this.navCtrl.present(alert).then(() => {
      this.testRadioOpen = true;
    });*/
  }
 
  doCheckbox() {
    let alert = this.alertCtrl.create();
    alert.setTitle('Which planets have you visited?');
 
    alert.addInput({
      type: 'checkbox',
      label: 'Alderaan',
      value: 'value1',
      checked: true
    });
 
    alert.addInput({
      type: 'checkbox',
      label: 'Bespin',
      value: 'value2'
    });
 
    alert.addInput({
      type: 'checkbox',
      label: 'Coruscant',
      value: 'value3'
    });
 
    alert.addInput({
      type: 'checkbox',
      label: 'Endor',
      value: 'value4'
    });
 
    alert.addInput({
      type: 'checkbox',
      label: 'Hoth',
      value: 'value5'
    });
 
    alert.addInput({
      type: 'checkbox',
      label: 'Jakku',
      value: 'value6'
    });
 
    alert.addInput({
      type: 'checkbox',
      label: 'Naboo',
      value: 'value6'
    });
 
    alert.addInput({
      type: 'checkbox',
      label: 'Takodana',
      value: 'value6'
    });
 
    alert.addInput({
      type: 'checkbox',
      label: 'Tatooine',
      value: 'value6'
    });
 
    alert.addButton('Cancel');
    alert.addButton({
      text: 'Okay',
      handler: data1 => {
        console.log('Checkbox data:', data1);
        this.testCheckboxOpen = true;
        this.testCheckboxResult = data1; 
        
      }
    });
  alert.present();
 
    /*this.nav.present(alert).then(() => {
      this.testCheckboxOpen = true;
    });*/
  }

}