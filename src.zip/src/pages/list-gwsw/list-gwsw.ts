import {Component} from "@angular/core"
import {NavController,NavParams} from "ionic-angular"
import { LISTgwsw } from "./../../model/LISTgwsw"
import { HomeService } from "../../providers/home-service";
import { TablePage } from "../table/table";
import { TableWjclPage } from "../table-wjcl/table-wjcl";

@Component({
    selector:'ppage-list-gwsw',
    templateUrl:'list-gwsw.html',
     providers:[HomeService]
})
 
export class ListGwswPage{

  tablePage=TablePage;
  TableWjclPage=TableWjclPage;
	items2=[];
    items1 = []; 
    items:Array<{title:String}>;
  mobileList: LISTgwsw;s
    constructor(public navCtrl: NavController,navParams:NavParams,
    private service: HomeService
    ) {
    	this.getInfo(1);
        this.items = [{title: 'item1'},
        {title: 'item2'},
        {title: 'item3'},
        {title: 'item4'},
        {title: 'item5'},
        {title: 'item6'},
        {title: 'item7'},
        {title: 'item8'},
        {title: 'item9'},
        {title: 'item10'},
        {title: 'item11'},
        {title: 'item12'},
        {title: 'item13'},
        {title: 'item14'},
        {title: 'item15'}];
        // for (var i = 0; i < 30; i++) {
        //   // this.items.push({title:"name"+this.items.length} );
        //   this.items3.push( {title:"item15"+i} );
        // }
    }

    // doInfinite(infiniteScroll){
    //     console.log('22');
    //     setTimeout(() => {
    //         console.log('3');
    //         infiniteScroll.complete();
    //     }, 500);
    // }
   //上拉加载
  doInfinite(infiniteScroll) {
    console.log('刷新操作');
 
    setTimeout(() => {
      for (let i = 0; i < 30; i++) {
        this.items.push( {title:"item15"+i} );
      }
 
      console.log('加载结束');
      infiniteScroll.complete();
    }, 500);
  }
 //下拉刷新
  doRefresh(refresher) {
    console.log('加载操作', refresher);
 
    setTimeout(() => {
      this.items = [];
      for (var i = 0; i < 30; i++) {
        this.items.push( {title:"item15"+i});
      }
      console.log('刷新结束');
      refresher.complete();
    }, 2000);
  }
   getInfo(value) {


      var url = "/API/DocumentList/";

       this.service.get(url).then(data=>{console.log(data);
        var str=JSON.stringify(data)
 
         var objs = JSON.parse(str); //由JSON字符串转换为JSON对象
           var obj= JSON.parse(objs.Result); 
     
           for(let i=0;i<obj.length;i++){
              this.mobileList=obj[i];
            this.items2.push({
            	CASENO:this.mobileList.CASENO,
            	TITLE:this.mobileList.TITLE,
              WRITER:this.mobileList.WRITER,
            	WRITERID:this.mobileList.WRITERID,
            	WRITERDATE:this.mobileList.WRITERDATE,
            	WNO:this.mobileList.WNO,
            	FILETYPE:this.mobileList.FILETYPE,
							WENHAONO:this.mobileList.WENHAONO,
            	TXTSWYEAR:this.mobileList.TXTSWYEAR,
							TXTSWHAO:this.mobileList.TXTSWHAO,
            	SWLX:this.mobileList.SWLX,
            	UNUSED8:this.mobileList.UNUSED8,
            	DBLX:this.mobileList.DBLX,
            	SENDFLAG:this.mobileList.SENDFLAG,
            })
            // alert(this.mobileList.CASENO);
           }
        });
  }

}