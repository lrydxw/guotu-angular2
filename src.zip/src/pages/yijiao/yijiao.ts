import { Component } from '@angular/core';
import { NavController, NavParams , AlertController} from 'ionic-angular';
import { HomeService } from "../../providers/home-service";
import { Renyuan } from "./../../model/Renyuan";
/*
  Generated class for the Yijiao page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-yijiao',
  templateUrl: 'yijiao.html',
  providers: [HomeService]
})
export class YijiaoPage {
	mobileInfo: Renyuan;	
  mobileInfosave: Renyuan;			
	testCheckboxOpen: boolean;
	testCheckboxResult;		  
	pet:string="向后"; 
	id: number; // 用来接收上一个页面传递过来的参数
	items=[];
  profilePicture: any="assets/icon/main_icon_zoomout.png";
  constructor(public navCtrl: NavController, 
  public navParams: NavParams,
  private alertCtrl: AlertController,
  public service: HomeService) {
  	var tab1=document.getElementById('tab1');
		var tab2=document.getElementById('tab2');
		var tab3=document.getElementById('tab3');	}

  ionViewDidLoad() {
	 this.getInfo(false,"#TKQBG2017022140004","ZENGYI","0")
  	
  	var tab1=document.getElementById('tab1');
		var tab2=document.getElementById('tab2');
		var tab3=document.getElementById('tab3');
    console.log('ionViewDidLoad YijiaoPage');
    tab1.style.display = 'block';
 				tab2.style.display = 'none';
  	 		tab3.style.display='none';/**/
  }
  tab1(){
  	console.log('tab1')
  	var tab1=document.getElementById('tab1');
		var tab2=document.getElementById('tab2');
		var tab3=document.getElementById('tab3');


		  	tab1.style.display = 'block';
 				tab2.style.display = 'none';
  	 		tab3.style.display='none';
  	//this.doCheckbox();
  }

 tab2(){
  	console.log('tab2')
var tab1=document.getElementById('tab1');
		var tab2=document.getElementById('tab2');
		var tab3=document.getElementById('tab3');
  			tab1.style.display = 'none';
 				tab2.style.display = 'block';
  	 		tab3.style.display='none';
  }

  tab3(){
  	console.log('tab3')
  		var tab1=document.getElementById('tab1');
		var tab2=document.getElementById('tab2');
		var tab3=document.getElementById('tab3');
  			tab1.style.display = 'none';
 				tab2.style.display = 'none';
  	 		tab3.style.display='block';
  }
    doCheckbox() {
    let alert = this.alertCtrl.create();
    alert.setTitle('Which planets have you visited?');
 
    alert.addInput({
      type: 'checkbox',
      label: 'Alderaan',
      value: 'value1',
      checked: true
    });
 
    alert.addInput({
      type: 'checkbox',
      label: 'Bespin',
      value: 'value2'
    });
 
    alert.addInput({
      type: 'checkbox',
      label: 'Coruscant',
      value: 'value3'
    });
 
    alert.addInput({
      type: 'checkbox',
      label: 'Endor',
      value: 'value4'
    });
 
    alert.addInput({
      type: 'checkbox',
      label: 'Hoth',
      value: 'value5'
    });
 
    alert.addInput({
      type: 'checkbox',
      label: 'Jakku',
      value: 'value6'
    });
 
    alert.addInput({
      type: 'checkbox',
      label: 'Naboo',
      value: 'value6'
    });
 
    alert.addInput({
      type: 'checkbox',
      label: 'Takodana',
      value: 'value6'
    });
 
    alert.addInput({
      type: 'checkbox',
      label: 'Tatooine',
      value: 'value6'
    });
 
    alert.addButton('Cancel');
    alert.addButton({
      text: 'Okay',
      handler: data1 => {
        console.log('Checkbox data:', data1);
        this.testCheckboxOpen = true;
        this.testCheckboxResult = data1; 
        
      }
    });
  alert.present();
 
    /*this.nav.present(alert).then(() => {
      this.testCheckboxOpen = true;
    });*/
  }
    //获取移交人员信息
    getInfo(ischecked,CASENO,GongHao,TYPE) {
		  var url = "/API/MOBILECASEINFOUser/";
		//  var jsonstr= '{"CASENO":"#TKQBG2017022140004","GongHao":"ZENGYI","TYPE":"0"}';
      var jsonstr= '{"CASENO":"'+ CASENO +'","GongHao":"'+ GongHao +'","TYPE":"'+ TYPE +'"}';
		  let body=  JSON.parse(jsonstr);

		  this.service.post(url,body).then(data=>{console.log(data);
		  var str=JSON.stringify(data)
		  var objs = JSON.parse(str); //由JSON字符串转换为JSON对象
		  var obj= JSON.parse(objs.Result); 

		    console.log(obj);
        this.items=[];
		  for(let i=0;i<obj.length;i++){
		    this.mobileInfo=obj[i];
   
        var arr = this.mobileInfo.UserName.split(','); // 分割参数
           var arrid = this.mobileInfo.UserID.split(','); // 分割参数
      for(let i=0;i< arr.length;i++){ 
		        this.items.push({groupChecked:ischecked,UserID:arrid[i],UserName:arr[i]});
      }
          
		 
		  }
		  
		});
	}
 
     openHide(){
  var div1=document.getElementById("div2");
  var span=document.getElementById("spanid");
  if(div1.style.display=="block"){
    div1.style.display="none";
   // span.innerHTML="+  111111111111111111111";
  }else{
    div1.style.display="block";
        //span.innerHTML="-  111111111111111111111";
  }
}
 
   // 移动端移交方向,-1:向后；0：平级；1：向后
     //保存功能
     save(val) {
       var LID0="1951407";
       var tabType="1"
       var HANDINFO="";
      
       for (let i = 0; i < this.items.length; i++) {
         this.mobileInfosave = this.items[i];
         if (this.mobileInfosave.groupChecked == true) {
           HANDINFO += this.mobileInfosave.UserID + "|"
         }
       }
        if(HANDINFO=="")
       {
           alert("移交人员不能为空，请选择人员!");  
           return;
       }
       HANDINFO = HANDINFO.substr(0, HANDINFO.length - 1);
       var datatime = getNowFormatDate();
       var url = "/API/UpdateHand";
       var jsonstr = '{"LID0":"' + LID0 + '","HANDDIRECT":"' + tabType + '","HANDINFO":"' + HANDINFO + '","HANDTIME":"' + datatime + '","CHANGEFLG":"1"}';
       let body = JSON.parse(jsonstr);
       this.service.post(url, body).then(data => {
         var str = JSON.stringify(data)
         console.log("str", str);
         var objs = JSON.parse(str); //由JSON字符串转换为JSON对象
         var obj = JSON.parse(objs.Result);
         if (obj.data == "1") {
           alert("移交成功!");    
           //document.getElementById("btn").disabled=true;
         } else {
           //document.getElementById("btn").disabled=false;
           // oBtn.disabled = 'disabled';
         }
       });
     }
  
   //全选功能
   selectCheckId(ev, item) {
     //let val = ev;
    // alert(val.checked);
     this.getInfo(ev.checked, "#TKQBG2017022140004", "ZENGYI", "0")
   }


}


function getNowFormatDate() {
   var month ;
    var strDate ;
    var date = new Date();
    var seperator1 = "-";
    var seperator2 = ":";
      month = date.getMonth() + 1;
     strDate = date.getDate();
    if (month >= 1 && month <= 9) {
        month = "0" + month;
    }
    if (strDate >= 0 && strDate <= 9) {
        strDate = "0" + strDate;
    }
    var currentdate = date.getFullYear() + seperator1 + month + seperator1 + strDate
            + " " + date.getHours() + seperator2 + date.getMinutes()
            + seperator2 + date.getSeconds();
    return currentdate;
}

 
