import { Component } from '@angular/core';
import { InformationPage } from '../information/information';
import { UpdatePage } from '../update/update';
import { NavController } from 'ionic-angular';
import { AlertController } from 'ionic-angular';
@Component({
  selector: 'page-contact',
  templateUrl: 'contact.html'
})
export class ContactPage {
 // InformationPage=InformationPage
 constructor(public navCtrl: NavController,
             private   alertCtrl: AlertController) {     

    }
 
  
 information(){
     this.navCtrl.push(InformationPage);
    }  

 update(){
    this.navCtrl.push(UpdatePage);
 }

  our(){
     let alert = this.alertCtrl.create({
      title: '智慧国土:',
      message: '当前版本:V3.2.8',
     
    });
    alert.present();
   }
 
 loginout(){
     let confirm = this.alertCtrl.create({
      title: '温馨提示:',
      message: '你确定要退出程序吗?',
      buttons:[
         {
            text:'确定'
         },
         {
            text:'取消'
         }
      ]

    });
    confirm.present();
 }


}

