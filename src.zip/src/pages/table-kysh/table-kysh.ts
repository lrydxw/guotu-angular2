import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import {HomeService} from "../../providers/home-service";
import { ZswfReceiveDocForm } from "./../../model/ZswfReceiveDocForm"
/*
  Generated class for the TableKYSH page.

  See http://ionicframework.com/docs/v2/components/#navigation for more info on
  Ionic pages and navigation.
*/
@Component({
  selector: 'page-table-kysh',
  templateUrl: 'table-kysh.html',
  providers:[HomeService]
  
})
export class TableKYSHPage {
  id: number;// 用来接收上一个页面传递过来的参数
profilePicture: any="assets/icon/date.ICO";
  mobileInfo: ZswfReceiveDocForm;
  constructor(public navCtrl: NavController, public navParams: NavParams,public service:HomeService) {}

  ionViewDidLoad() {
    console.log('ionViewDidLoad TableKYSHPage');
     this.getInfo(this.id);
    
  }
  getInfo(value) {


      var url = "/API/ZSWFRECEIVEDOCFORMorK_SPBbyCaseno/'#TKQKC2016042940008'";

       this.service.get(url).then(data=>{console.log(data);
        var str=JSON.stringify(data)

         var objs = JSON.parse(str); //由JSON字符串转换为JSON对象
           var obj= JSON.parse(objs.Result); 
       
           for(let i=0;i<obj.length;i++){
              this.mobileInfo=obj[i];
           console.log(this.mobileInfo)
           }
        });
  }


}
