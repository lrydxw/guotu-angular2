export class SetTZHUIQIAN {
    OPINIONCONTEXT:string;  //主管厅长意见设置
}		
