export class FileColumn {
    MTRNAME:string;  //附件表名
    CASENO:string;  //附件编号
    MTRTYPE:string;  //附件类型
    MTRNUM:number;
}		
