export class FIELDS {
    ALIAS:string;
    DbSize:number;
    FieldType:string;
    Name:string;
    Name2:string;
}		
