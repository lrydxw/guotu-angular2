export class TBghtzXS {
      CASENO :string;//案卷编号
      GHCSCXX :string;//规划处审查标志
      GHCSHXX :string;//规划处审核标志
      GHCFHXX :string;//规划处复核标志  规划处复核标志：0、请选择，1、建议此次申请不予许可，2、拟同意此次申请
      
      DJCSCXX :string;//地籍处审查标志
      DJCSHXX :string;//地籍处审核标志
      DJCFHXX:string;//地籍处复核标志
      LYCSCXX :string;//利用处审查标志
      LYCSHXX :string;//利用处审核标志
      LYCFHXX :string;//利用处复核标志
      ZZJSCXX :string;//整治局审查标志
      ZZJSHXX :string;//整治局审核标志
      ZZJFHXX :string;//整治局复核标志
      ZZJSPXX :string;//整治局审批标志
      ZHYJSC :string;//综合意见审查标志 综合意见复核标志：0、请选择，1、同意许可，2、不予许可，3、会审决定
      ZHYJFH :string;//综合意见复核标志 综合意见复核标志：0、请选择，1、同意许可，2、不予许可，3、会审决定
      QFXX :string;//厅长签发标志
      SENDFLAG :string;//
        
    
}		
