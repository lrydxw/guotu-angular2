export class FieldPower {
    ID:number;  //ID
    FLOWID:number;  //流程ID
    NODEID:number;  //
    OPINIONCODE:string;  //
    OPINIONNAME:string;  //
    TABLENAME: string;   //表名
    KEYNAME:string;  //
    OPINIONTYPE:string;  //
    OPICOLUMN:string;
    OPIUSERKEY:string;
    OPIDATEKEY:string;
    SAVETYPE:string;
    GLYJTYPE:string;
    TKHSLXNAME:string;
    TKHSLXVALUE:string;
    TKHSCSNAME:string;
    TKHSCSVALUE:string;
}		