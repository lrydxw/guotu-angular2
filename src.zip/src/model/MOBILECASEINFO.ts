export class MOBILECASEINFO {
      ID0:number;//主键;自动增长
      CASENO:string;//案卷编号
      CASENAME:string;;//案卷名称
      FLOWID:number;//流程ID
      FLOWNAME:string;//流程名称
      NODEID:number;//节点ID
      NODENAME:string;//节点名称
      CURUSERID:number;//当前办理人ID
      CURUSERNAME:string;//当前办理人姓名
      CURDATE:string;//承办时间
      EVENTCODE:string;//事件号
      EVENTNAME:string;//事件名称
      PREINFO:string;//前承办信息：节点1ID|用户1ID,用户2ID; 节点2ID|用户3ID,用户4ID;
      LVINFO :string;//平级承办信息：节点1ID|用户1ID,用户2ID; 节点2ID|用户3ID,用户4ID;
      NEXTINFO :string;//后承办信息：节点1ID|用户1ID,用户2ID; 节点2ID|用户3ID,用户4ID;
      CHANGEFLG :number;//交换标志，默认为0
      ERRORINFO :string;//异常情况下移交异常信息
      
     
}		
