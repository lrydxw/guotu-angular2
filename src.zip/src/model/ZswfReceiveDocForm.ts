export class ZswfReceiveDocForm {
      CASENO :string;//案卷编号
      BUSINESSKIND :string;//案卷类型
      LIMITDAY :string;//办理时限
      FACTBUSINESS :string;//案卷名称
      APPLYUNIT :string;//报件单位
      UNDERTAKER :string;//承办人
      RECEIVEMAN :string;//收件人
      RECEIVEDATE :string;//收件日期
      APPLYMAN :string;//
      RECEIVEPHOHE :string;//收件人联系电话
      APPLYPHONE :string;//报件人联系电话
      AREACODE :string;//行政区划
      BGSCSYJ :string;//办公室初始意见
      DTFZR :string;//大厅负责人
      BMSCYJ :string;//大厅初审意见
      DECBLQK :string;//
      REMARK :string;//
      BJ_MAIL :string;//
      LSTDBZ :string;//绿色通道标志
      DATAEXCHANGEFLG :string;//DATAEXCHANGE_FLG
      FUWUZHONGDIAN :string;//耕保处服务重点
      
      
      
      TKSCYJ :string;//处长复核意见
      TKPEOPLE :string;//复核人
      TKTIME :string;//复核时间
      CKSCYJ :string;//探矿权/采矿权办理人员意见
      CKPEOPLE :string;//探矿权/采矿权办理人员
      CKTIME :string;//探矿权/采矿权办理人员审查时间
      JDSCTJ :string;//监督管理人员审查意见
      JDSCR :string;//监督管理审查人
      JDSCTIME :string;//监督管理审查时间
      JDSHYJ :string;//汇总意见
      JDSHR :string;// 汇总意见审查人
      JDSHTIME :string;//汇总意见审查时间
      HUISHENYJ :string;//
      HUISHENPEOPLE :string;//
      HUISHENTIME :string;//
      BEIZHU :string;//
      UNUSED1 :string;//分管处长审核意见
      UNUSED2 :string;//分管处长
      UNUSED3 :string;//分管处长审核时间
      UNUSED4 :string;//设置方案审查意见
      UNUSED5  :string;//设置方案审查人
      UNUSED6  :string;//设置方案审查时间
      UNUSED7  :string;//有偿化处置审查意见
      UNUSED8  :string;//有偿化处置审查人
      UNUSED9  :string;//有偿化处置审查时间
      HUIQIANJILUREN  :string;//
      DATAEXCHANGE_FLG  :string;//
      QFYJ  :string;//签发意见
      QFR  :string;//签发人
      QFRQ  :string;//签发日期
      FHXX  :string;//矿管处复核选项：0、请选择，1、同意许可，2、不予许可，3、会审决定
      
      QFXX  :string;//签发选项：SELECT * FROM SYSDATADICTIONARY where parentid=877
      
      HSXX  :string;//矿权互审选项：0、请选择，1、建议此次申请不予许可，2、拟同意此次申请
      JDXX  :string;//监督审核选项：0、请选择，1、建议此次申请不予许可，2、拟同意此次申请
      FAXX  :string;//设置方案选项：0、请选择，1、建议此次申请不予许可，2、拟同意此次申请
      CZXX  :string;//有偿化处置选项：0、请选择，1、建议此次申请不予许可，2、拟同意此次申请
	    HZXX  :string;//矿管处汇总选项：0、请选择，1、同意许可，2、不予许可，3、会审决定
      SHXX  :string;//矿管处审核选项：0、请选择，1、同意许可，2、不予许可，3、会审决定
      BYXKSY  :string;//不予许可事由
      DJR  :string;//登记人
      DJRQ  :string;//登记日期
      SFJQ  :string;//本次价款是否缴清：0、未缴清，1、已缴清
      XCBLZY  :string;//下次办理注意事项
     

      SENDFLAG  :number;//

      GWZWNEIRONG2 :string;//公文内容
     
}		
