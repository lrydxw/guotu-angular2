export class LISTgwsw {
      CASENO:string;//
      TITLE:string;;//
      WRITER:number;//
      WRITERID:string;//
      WRITERDATE:number;//
      WNO:string;//
      FILETYPE:number;//
      WENHAONO:string;//
      TXTSWYEAR:string;//
      TXTSWHAO:string;//
      SWLX:string;//
      UNUSED8:string;//
      DBLX :string;//
      SENDFLAG :string;//
     
     
}		
