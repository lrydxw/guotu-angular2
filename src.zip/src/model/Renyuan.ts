export class Renyuan {

    NodeID:string;
    NodeName:string;
    UserID:string;
    UserName:string;
   groupChecked:Boolean;
     
}		
