export class Data {
    BSM:number;
    ALIAS:string;
    LAYERTYPE:string;
    NAME:string;
    PATH:string;
    TABLENAME:string;
    VERSION:string;
}		
