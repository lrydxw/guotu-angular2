export class ZswfReceiveDocForm {
      TITLE :string;//案卷编号
      SWLX :string;//案卷类型
      TXTSWYEAR :string;//办理时限
      TXTSWHAO :string;//案卷名称
      UNUSED6 :string;//报件单位
      UNUSED7 :string;//承办人
      DBLX:string;
      DBBLSX :string;//收件人
      WNO :string;//收件日期
      WENHAONO :string;//
      UNUSED10 :string;//收件人联系电话
      JINJICD :string;//报件人联系电话
      UNUSED8 :string;//行政区划
      UNUSED9 :string;//办公室初始意见
      UNUSED2 :string;//大厅负责人
      UNUSED3 :string;//大厅初审意见
      SWHZYJ :string;//
      Table_Id :string;//
      BJ_MAIL :string;//
      LSTDBZ :string;//绿色通道标志
      DATAEXCHANGEFLG :string;//DATAEXCHANGE_FLG
      FUWUZHONGDIAN :string;//耕保处服务重点
      GWTYPE:string;
      
   
}		
