export class KTKhsMobile {
      CASENO :string;//案卷编号
      GHCSCYJ :string;//规划处审查意见
      GHCSCSJ :string;//规划处审查时间
      GHCSCR :string;//规划处审查人
      GHCSCXX :string;//规划处审查标志
      GHCSHYJ :string;//规划处审核意见
      GHCSHSJ :string;//规划处审核时间
      GHCSHR :string;//规划处审核人
      GHCSHXX :string;//规划处审核标志
      GHCFHYJ :string;//规划处复核意见
      GHCFHSJ :string;//规划处复核时间
      GHCFHR :string;//规划处复核人
      GHCFHXX :string;//规划处复核标志
      ZYCSCYJ :string;//资源处审查意见
      ZYCSCSJ :string;//资源处审查时间
      ZYCSCR :string;//资源处审查人
      ZYCSCXX :string;//资源处审查标志
      ZYCSHYJ :string;//资源处审核意见
      ZYCSHSJ :string;//资源处审核时间
      ZYCSHR :string;//资源处审核人
      ZYCSHXX :string;//资源处审核标志

      
      
      
      DKZXSCYJ :string;//地勘基金中心审查意见
      DKZXSCSJ :string;//地勘基金中心审查时间
      DKZXSCR :string;//地勘基金中心审查人
      DKZXSCXX :string;//地勘基金中心审查标志
      DKZXSHYJ :string;//地勘基金中心审核意见
      DKZXSHSJ :string;//地勘基金中心审核时间
      DKZXSHR :string;//地勘基金中心审核人
      DKZXSHXX :string;//地勘基金中心审核标志
      DKCSCYJ :string;//地质勘查处审查意见
      DKCSCSJ :string;//地质勘查处审查时间
      DKCSCR :string;// 地质勘查处审查人
      DKCSCXX :string;//地质勘查处审查标志
      DKCSHYJ :string;//地质勘查处审核意见
      DKCSHSJ :string;//地质勘查处审核时间
      DKCSHR :string;//地质勘查处审核人
      DKCSHXX :string;//地质勘查处审核标志
      
      
      
      规划处审查意见 :string;//地质勘查处审核标志
      规划处审查时间 :string;//地质勘查处审核标志
      规划处审查人 :string;//地质勘查处审核标志
      规划处审查标志 :string;//地质勘查处审核标志
      规划处审核意见 :string;//地质勘查处审核标志
      规划处审核时间 :string;//地质勘查处审核标志
      规划处审核人 :string;//地质勘查处审核标志
      规划处审核标志 :string;//地质勘查处审核标志
      规划处复核意见 :string;//地质勘查处审核标志
      规划处复核时间 :string;//地质勘查处审核标志
      规划处复核人 :string;//地质勘查处审核标志
      规划处复核标志 :string;//地质勘查处审核标志
      资源处审查意见 :string;//地质勘查处审核标志
      资源处审查时间 :string;//地质勘查处审核标志
      资源处审查人 :string;//地质勘查处审核标志
      资源处审查标志 :string;//地质勘查处审核标志
      资源处审核意见 :string;//地质勘查处审核标志
      资源处审核时间 :string;//地质勘查处审核标志
      资源处审核人 :string;//地质勘查处审核标志
      资源处审核标志 :string;//地质勘查处审核标志
      地勘基金中心审查意见 :string;//地质勘查处审核标志
      地勘基金中心审查时间 :string;//地质勘查处审核标志
      地勘基金中心审查人 :string;//地质勘查处审核标志
      地勘基金中心审查标志 :string;//地质勘查处审核标志
      地勘基金中心审核意见 :string;//地质勘查处审核标志
      地勘基金中心审核时间 :string;//地质勘查处审核标志
      地勘基金中心审核人 :string;//地质勘查处审核标志
      地勘基金中心审核标志 :string;//地勘基金中心审查意见
      
      地质勘查处审查意见 :string;//地质勘查处审核标志
      地质勘查处审查时间:string;//地质勘查处审核标志
      地质勘查处审查人 :string;//地质勘查处审核标志
      地质勘查处审查标志:string;//地质勘查处审核标志
  

      地质勘查处审核意见 :string;//地勘基金中心审查时间
      地质勘查处审核时间 :string;//地勘基金中心审查人
      地质勘查处审核人 :string;//地勘基金中心审查标志
      地质勘查处审核标志 :string;//地勘基金中心审核意见
      SENDFLAG :string;//资源处审核标志s
      
       
      
      

     
}		
