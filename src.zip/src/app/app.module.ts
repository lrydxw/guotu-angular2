import { NgModule, ErrorHandler } from '@angular/core';
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';
import { MyApp } from './app.component';
import { AboutPage } from '../pages/about/about';
import { ContactPage } from '../pages/contact/contact';
import { HomePage } from '../pages/home/home';
import { UpdatePage } from '../pages/update/update';
import { ThongzhiPage } from '../pages/thongzhi/thongzhi';
import { YewuPage } from '../pages/yewu/yewu';
import { LeadPage } from '../pages/lead/lead';
import { QuotePage } from '../pages/quote/quote';
import { TablePage } from '../pages/table/table';
import { TableKYSHPage } from '../pages/table-kysh/table-kysh';
import { TableTKXKPage } from '../pages/table-tkxk/table-tkxk';
import { TableWjclPage } from '../pages/table-wjcl/table-wjcl';
import { TableCKGHPage } from '../pages/table-ckgh/table-ckgh';
import { TableGhtzPage } from '../pages/table-ghtz/table-ghtz';
import { YijiaoPage } from '../pages/yijiao/yijiao';
import { FilePage } from '../pages/file/file';

import { InformationPage } from '../pages/information/information';
import { TabsPage } from '../pages/tabs/tabs';
import { LoginPage } from '../pages/login/login';
import { List1Page } from '../pages/List1/List1';
import { ListGwswPage } from '../pages/list-gwsw/list-gwsw'; 

@NgModule({
  declarations: [
    MyApp,
    AboutPage,
    ContactPage,
    HomePage,
    TabsPage,
    UpdatePage,
    ThongzhiPage,
    YewuPage,
    LeadPage,
    InformationPage,
    LoginPage,
    QuotePage,
    TablePage,
    List1Page,
    YijiaoPage,
    FilePage,
    TableKYSHPage,
    TableTKXKPage,
    TableWjclPage,
    TableCKGHPage,
    TableGhtzPage,
    ListGwswPage
  ],
  imports: [
    IonicModule.forRoot(MyApp)
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    AboutPage,
    ContactPage,
    HomePage,
    TabsPage,
    UpdatePage,
    ThongzhiPage,
    YewuPage,
    LeadPage,
    InformationPage,
    LoginPage,
    QuotePage,
    TablePage,
    List1Page,
    YijiaoPage,
    FilePage,
    TableKYSHPage,
    TableTKXKPage,
    TableWjclPage,
    TableCKGHPage,
    TableGhtzPage,
    ListGwswPage
  ],
  providers: [{provide: ErrorHandler, useClass: IonicErrorHandler}]
})
export class AppModule {}
