import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Headers, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map';

@Injectable()
export class HomeService {
	httpUrl: string;
	constructor(public http: Http) {
		console.log('Hello HomeService Provider');
		//this.httpUrl = "http://192.168.1.209:8081";
		  this.httpUrl="http://115.29.241.3:1088";
	}

	get(url: string) {
		console.log(this.httpUrl + url);
		return new Promise((resolve, reject) => {
			this.http.get(this.httpUrl + url)
				.map(res => res.json())
				.subscribe(data => {
					console.log(data);
					resolve(data);
				}, err => {
					reject(err);
				})
		})
	}

	post(url: string, body: any) {
		var headers = new Headers();
		headers.append('Content-Type', 'application/json');
		let options = new RequestOptions({ headers: headers });
		//let body= "username=15867172306&password=123";
		return new Promise((resolve, reject) => {
			this.http.post(this.httpUrl + url, body, options)
				.map(res => res.json())
				.subscribe(data => resolve(data), err => reject(err))
		})
	}
	/*
	    post() {
	        let header = new Headers();
	        header.append('Content-Type', 'application/x-www-form-urlencoded');
	        let pramas = JSON.stringify({ username: "", password: "" })
	        return new Promise((resolve, reject) => {
	            this.http.post("http://localhost:6005/XBETC/Account/Login", pramas, header)
	                .map(res => res.json())
	                .subscribe(data => resolve(data), err => reject(err))
	        })
	    }
	*/
}